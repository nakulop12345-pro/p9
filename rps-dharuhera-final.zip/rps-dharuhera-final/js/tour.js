(function(){
RPS.initTour=function(stage){
const $=id=>document.getElementById(id);let i=-1;
function show(n){i=(n+RPS.TOUR.length)%RPS.TOUR.length;const s=RPS.TOUR[i],z=RPS.ZONES.find(x=>x.id===s[0]),v=z?{c:z.c,t:z.t}:RPS.HERO;
$("tCount").textContent=String(i+1).padStart(2,"0")+" / "+String(RPS.TOUR.length).padStart(2,"0");$("tName").textContent=(z?z.name:"Campus view").toUpperCase();$("tText").textContent=s[1];
$("tourBar").hidden=false;$("panel").hidden=true;stage.flyTo(v.c,v.t,2.4)}
function exit(quiet){if(i<0)return;i=-1;$("tourBar").hidden=true;if(!quiet)stage.flyTo(RPS.HERO.c,RPS.HERO.t,1.8)}
RPS.tour={start(){show(0)},exit,next(){show(i+1)},prev(){show(i-1)}};
$("tNext").onclick=()=>show(i+1);$("tPrev").onclick=()=>show(i-1);$("tExit").onclick=()=>exit();
addEventListener("keydown",e=>{if(i<0)return;if(e.key==="ArrowRight")show(i+1);if(e.key==="ArrowLeft")show(i-1);if(e.key==="Escape")exit()})};})();
