(function(){
RPS.createStage=function(canvas){
const T=THREE,mobile=/Android|iPhone|iPad|Mobile/i.test(navigator.userAgent)||innerWidth<769;
const reduce=matchMedia("(prefers-reduced-motion:reduce)").matches;
const renderer=new T.WebGLRenderer({canvas,antialias:!mobile});
renderer.outputEncoding=T.sRGBEncoding;renderer.toneMapping=T.ACESFilmicToneMapping;
renderer.shadowMap.enabled=true;renderer.shadowMap.type=T.PCFSoftShadowMap;
const scene=new T.Scene(),camera=new T.PerspectiveCamera(45,1,.5,700);
scene.fog=new T.Fog(0xbcd4e6,120,360);
const controls=new T.OrbitControls(camera,canvas);
controls.enableDamping=true;controls.dampingFactor=.07;controls.maxPolarAngle=1.45;controls.minDistance=12;controls.maxDistance=190;controls.target.set(0,0,4);
camera.position.set(150,100,160);
const hemi=new T.HemisphereLight(0xdff0ff,0x3a4a35,.9);scene.add(hemi);
const sun=new T.DirectionalLight(0xfff1d6,1.4);sun.position.set(60,90,50);scene.add(sun);
const sc=sun.shadow.camera;sc.left=sc.bottom=-75;sc.right=sc.top=75;sc.far=260;sun.shadow.bias=-.0004;
const dayBg=new T.Color(0xbcd4e6),nightBg=new T.Color(0x070b16),bg=new T.Color();
const st={n:0,nt:0,quality:mobile?"eco":"high",fly:null,visible:true,cbs:[],mobile};
function setQuality(q){st.quality=q;const hi=q==="high";
renderer.setPixelRatio(hi?Math.min(devicePixelRatio,2):1);
sun.castShadow=hi&&!mobile||(hi&&mobile);sun.shadow.mapSize.set(mobile?1024:2048,mobile?1024:2048);
if(sun.shadow.map){sun.shadow.map.dispose();sun.shadow.map=null}
document.getElementById("qLabel").textContent=hi?"High":"Eco";resize()}
function resize(){const p=canvas.parentElement,w=p.clientWidth,h=p.clientHeight;renderer.setSize(w,h,false);camera.aspect=w/h;camera.updateProjectionMatrix()}
new ResizeObserver(resize).observe(canvas.parentElement);
function flyTo(c,t,dur){dur=reduce?0:(dur==null?2.2:dur);
if(!dur){camera.position.set(...c);controls.target.set(...t);controls.update();st.fly=null;return}
st.fly={p0:camera.position.clone(),t0:controls.target.clone(),p1:new T.Vector3(...c),t1:new T.Vector3(...t),s:performance.now(),d:dur*1000}}
controls.addEventListener("start",()=>{st.fly=null;const h=document.getElementById("hint");if(h)h.style.opacity=0});
function applyNight(){const n=st.n;bg.copy(dayBg).lerp(nightBg,n);scene.background=bg;scene.fog.color.copy(bg);
sun.intensity=1.4-1.25*n;hemi.intensity=.9-.65*n;renderer.toneMappingExposure=1-.1*n;
sun.color.setHex(n>.5?0x8fa8ff:0xfff1d6);if(st.campus)st.campus.setNight(n)}
const clock=new T.Clock();
function frame(){requestAnimationFrame(frame);if(!st.visible||document.hidden)return;
const dt=Math.min(clock.getDelta(),.1),t=clock.elapsedTime;
if(st.fly){const f=st.fly,k=Math.min((performance.now()-f.s)/f.d,1),e=k<.5?4*k*k*k:1-Math.pow(-2*k+2,3)/2;
camera.position.lerpVectors(f.p0,f.p1,e);controls.target.lerpVectors(f.t0,f.t1,e);if(k>=1)st.fly=null}
if(Math.abs(st.n-st.nt)>.002){st.n+=(st.nt-st.n)*Math.min(dt*3,1);applyNight()}
controls.update();st.cbs.forEach(f=>f(t,dt));renderer.render(scene,camera)}
new IntersectionObserver(e=>{st.visible=e[0].isIntersecting}).observe(canvas.parentElement);
Object.assign(st,{renderer,scene,camera,controls,flyTo,setQuality,applyNight,
setNight(on){st.nt=on?1:0},isNight:()=>st.nt===1,toggleQuality:()=>setQuality(st.quality==="high"?"eco":"high"),
onFrame(f){st.cbs.push(f)},start(){setQuality(st.quality);applyNight();frame()},
intro(){flyTo(RPS.HERO.c,RPS.HERO.t,reduce?0:4.5)}});
return st}})();
