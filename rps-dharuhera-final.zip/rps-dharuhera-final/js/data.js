window.RPS=window.RPS||{};
RPS.HERO={c:[78,52,86],t:[0,0,4]};
RPS.ZONES=[
{id:"academic",name:"Academic block",pos:[0,-12],size:[34,12,12],c:[0,15,16],t:[0,5,-12],text:"The central teaching building, drawn here as a three-storey block with long glazed bands.",fact:"The school reports 85 classrooms across its campus."},
{id:"library",name:"Library",pos:[-26,-8],size:[14,9,12],c:[-34,10,12],t:[-26,3,-8],text:"A quiet reading wing at the western edge of the academic court.",fact:"The school reports a collection of 4,631+ books."},
{id:"science",name:"Science labs",pos:[26,-8],size:[14,9,12],c:[34,10,12],t:[26,3,-8],text:"A laboratory wing for hands-on practical work, shown with a rooftop skylight."},
{id:"sports",name:"Sports arena",pos:[-24,26],size:[28,3,20],c:[-24,17,50],t:[-24,0,26],text:"Open ground with a running track and goal posts.",fact:"The school reports a 4,113 m² playground."},
{id:"cricket",name:"Cricket area",pos:[26,28],size:[24,3,20],c:[28,16,52],t:[26,0,28],text:"A practice area with a turf pitch and net lanes."},
{id:"entrance",name:"Main entrance",pos:[0,46],size:[20,8,6],c:[0,6,64],t:[0,3,46],text:"The gate, signage and arrival drive, facing the Dharuhera–Bhiwadi Expressway."},
{id:"green",name:"Campus green",pos:[0,16],size:[22,4,14],c:[0,12,38],t:[0,1,16],text:"The central lawn with a fountain, pathways and shaded seating."},
{id:"parking",name:"Parking",pos:[40,8],size:[14,3,20],c:[60,13,16],t:[40,0,8],text:"A visitor and staff parking court beside the science wing."}];
RPS.TOUR=[["entrance","Welcome to the main entrance, where the drive meets the expressway."],["academic","The academic block anchors the centre of the campus."],["library","The library sits beside the academic court."],["science","The science wing is built for practical work."],["sports","The sports arena holds the track and playing field."],["cricket","The cricket area has a pitch and practice nets."],["green","The central green ties every part of the campus together."],["hero","Back to the full campus view."]];
