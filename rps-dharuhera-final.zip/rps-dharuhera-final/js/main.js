(function(){
const bar=document.getElementById("ldBar"),loader=document.getElementById("loader"),home=document.getElementById("home");
let p=0;const tick=setInterval(()=>{p=Math.min(p+Math.random()*14,90);bar.style.width=p+"%"},180);
const t0=performance.now();
function done(){clearInterval(tick);bar.style.width="100%";setTimeout(()=>loader.classList.add("done"),Math.max(0,700-(performance.now()-t0)))}
function fail(e){if(e)console.error(e);home.classList.add("no3d");done()}
function boot(){
if(!window.THREE||!THREE.OrbitControls)return fail();
try{
const stage=RPS.createStage(document.getElementById("stage"));
const campus=RPS.buildCampus(stage);
RPS.initInteraction(stage,campus);RPS.initTour(stage);
stage.start();stage.intro();RPS.stage=stage;done();
document.getElementById("stage").addEventListener("webglcontextlost",e=>{e.preventDefault();fail()});
}catch(e){fail(e)}}
if(document.readyState==="complete")boot();else addEventListener("load",boot);
setTimeout(()=>loader.classList.add("done"),9000);
})();
