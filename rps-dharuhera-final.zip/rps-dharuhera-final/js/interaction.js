(function(){
RPS.initInteraction=function(stage,campus){
const $=id=>document.getElementById(id),canvas=stage.renderer.domElement,ray=new THREE.Raycaster(),m=new THREE.Vector2();
let hover=null,sel=null,down=null;
function hit(e){const r=canvas.getBoundingClientRect();m.set((e.clientX-r.left)/r.width*2-1,-((e.clientY-r.top)/r.height)*2+1);ray.setFromCamera(m,stage.camera);const h=ray.intersectObjects(campus.picks,false);return h.length?h[0].object.userData.zone:null}
function select(id){const z=RPS.ZONES.find(x=>x.id===id);if(!z)return;sel=id;campus.select(id);
$("pTitle").textContent=z.name;$("pText").textContent=z.text;$("pFact").textContent=z.fact||"";$("pFact").hidden=!z.fact;$("panel").hidden=false;stage.flyTo(z.c,z.t,1.8)}
function reset(){sel=null;campus.select(null);$("panel").hidden=true;stage.flyTo(RPS.HERO.c,RPS.HERO.t,1.8)}
canvas.addEventListener("pointermove",e=>{if(e.pointerType!=="mouse")return;const id=hit(e);if(id!==hover){if(hover)campus.setHover(hover,false);hover=id;if(id)campus.setHover(id,true);canvas.style.cursor=id?"pointer":"grab"}});
canvas.addEventListener("pointerdown",e=>{down=[e.clientX,e.clientY]});
canvas.addEventListener("pointerup",e=>{if(!down)return;const moved=Math.hypot(e.clientX-down[0],e.clientY-down[1]);down=null;if(moved>6)return;const id=hit(e);if(id){RPS.tour&&RPS.tour.exit(true);select(id)}});
$("pClose").onclick=$("pReturn").onclick=reset;
$("bExplore").onclick=()=>{RPS.tour.exit(true);reset();$("hint").style.opacity=1};
$("bTour").onclick=()=>RPS.tour.start();
$("bDay").onclick=()=>stage.setNight(!stage.isNight());
$("bQuality").onclick=()=>stage.toggleQuality();
$("bReset").onclick=()=>{RPS.tour.exit(true);reset()};
const chips=$("chips");RPS.ZONES.forEach(z=>{const b=document.createElement("button");b.textContent=z.name;b.onclick=()=>{$("home").scrollIntoView({behavior:"smooth"});setTimeout(()=>select(z.id),450)};chips.appendChild(b)});
RPS.selectZone=select;RPS.resetView=reset;
};})();
