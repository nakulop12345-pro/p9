(function(){
const nav=document.getElementById("nav"),menu=document.getElementById("menu"),btn=document.getElementById("menuBtn");
const set=o=>{menu.classList.toggle("open",o);btn.setAttribute("aria-expanded",o);btn.setAttribute("aria-label",o?"Close menu":"Open menu");document.body.style.overflow=o?"hidden":""};
btn.onclick=()=>set(!menu.classList.contains("open"));menu.querySelectorAll("a").forEach(a=>a.addEventListener("click",()=>set(false)));
addEventListener("keydown",e=>{if(e.key==="Escape")set(false)});
const onScroll=()=>nav.classList.toggle("small",scrollY>60);addEventListener("scroll",onScroll,{passive:true});onScroll();
const links=[...menu.querySelectorAll("a")];
const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){links.forEach(a=>a.classList.toggle("on",a.getAttribute("href")==="#"+e.target.id))}}),{rootMargin:"-45% 0px -50% 0px"});
document.querySelectorAll("#home,.sec").forEach(s=>io.observe(s));
document.getElementById("yr").textContent=new Date().getFullYear();
})();
