(function(){
RPS.buildCampus=function(stage){
const T=THREE,scene=stage.scene,mob=stage.mobile,root=new T.Group();scene.add(root);
function tex(fn,rep){const c=document.createElement("canvas");c.width=c.height=128;const x=c.getContext("2d");fn(x);const t=new T.CanvasTexture(c);t.wrapS=t.wrapT=T.RepeatWrapping;t.repeat.set(rep,rep);t.encoding=T.sRGBEncoding;return t}
const noise=(base,amt)=>x=>{x.fillStyle=base;x.fillRect(0,0,128,128);for(let i=0;i<900;i++){const v=Math.random()*amt;x.fillStyle=`rgba(${Math.random()<.5?0:255},${Math.random()<.5?0:255},${Math.random()<.5?0:255},${v/255})`;x.fillRect(Math.random()*128,Math.random()*128,2,2)}};
const M=(c,r=.85,m=0,map)=>new T.MeshStandardMaterial({color:c,roughness:r,metalness:m,map});
const mat={grass:M(0x4b6b44,1,0,tex(noise("#fff",40),40)),road:M(0x2a2d33,.95),paved:M(0xb7b0a2,.9,0,tex(noise("#fff",30),6)),wall:M(0xe9e3d7,.85,0,tex(noise("#fff",22),3)),dark:M(0x1f2329,.5,.5),gold:M(0xc8a96a,.4,.8),white:M(0xf2f2f2,.7),trunk:M(0x4a3626,1),leaf:M(0x2f5b34,.9),track:M(0x9a4a3a,.95),turf:M(0x5f8a4e,1),pitch:M(0xc9b27c,1),
glass:new T.MeshStandardMaterial({color:0x6fa6cf,roughness:.08,metalness:.6,emissive:0xffd28a,emissiveIntensity:0}),
lamp:new T.MeshStandardMaterial({color:0xffffff,emissive:0xffd9a0,emissiveIntensity:.1})};
function box(w,h,d,x,y,z,m,p=root,cast=true){const o=new T.Mesh(new T.BoxGeometry(w,h,d),m);o.position.set(x,y,z);o.castShadow=cast;o.receiveShadow=true;p.add(o);return o}
const ground=new T.Mesh(new T.PlaneGeometry(420,420),mat.grass);ground.rotation.x=-Math.PI/2;ground.receiveShadow=true;root.add(ground);
// roads, paths, boundary
box(420,.1,16,0,.05,58,mat.road,root,false);box(.3,.12,16,0,.1,58,mat.gold,root,false);
box(8,.12,34,0,.06,28,mat.paved,root,false);box(100,.1,5,0,.05,44,mat.road,root,false);box(5,.1,100,-46,.05,0,mat.road,root,false);box(5,.1,90,46,.05,0,mat.road,root,false);
box(60,.12,6,0,.06,-1,mat.paved,root,false);box(8,.12,18,0,.06,6,mat.paved,root,false);
[[0,-45,100,1],[0,48,100,1]].forEach(a=>box(a[2],1.6,a[3],a[0],.8,a[1],mat.wall,root,false));[[-50,0,1,93],[50,0,1,93]].forEach(a=>box(a[2],1.6,a[3],a[0],.8,a[1],mat.wall,root,false));
// buildings
function building(x,z,w,d,h,floors,roofGlass){const g=new T.Group();g.position.set(x,0,z);root.add(g);
box(w,h,d,0,h/2,0,mat.wall,g);box(w+1.2,.5,d+1.2,0,h+.25,0,mat.dark,g);
for(let i=0;i<floors;i++){const y=h/floors*(i+.55);box(w-1.5,h/floors*.5,.3,0,y,d/2+.05,mat.glass,g,false);box(w-1.5,h/floors*.5,.3,0,y,-d/2-.05,mat.glass,g,false)}
box(w+.4,.35,d+.4,0,h/floors,0,mat.white,g,false);
if(roofGlass)box(w*.4,1.2,d*.5,0,h+1.1,0,mat.glass,g,false);return g}
building(0,-12,34,12,12,3);building(-26,-8,14,12,9,2);building(26,-8,14,12,9,2,true);
box(6,4,6,0,6,-2.4,mat.gold,root).scale.set(1,.4,1);
// gate + sign
const gate=new T.Group();gate.position.set(0,0,46);root.add(gate);
[-7,7].forEach(x=>box(2,7,2,x,3.5,0,mat.wall,gate));box(16,1.6,2.4,0,7.6,0,mat.dark,gate);
const sc=document.createElement("canvas");sc.width=512;sc.height=96;const sx=sc.getContext("2d");sx.fillStyle="#1f2329";sx.fillRect(0,0,512,96);sx.fillStyle="#c8a96a";sx.font="600 46px Georgia";sx.textAlign="center";sx.fillText("RPS DHARUHERA",256,62);
const sign=new T.Mesh(new T.PlaneGeometry(13,2.4),new T.MeshBasicMaterial({map:new T.CanvasTexture(sc)}));sign.position.set(0,7.6,1.25);gate.add(sign);
// sports
const sp=new T.Group();sp.position.set(-24,0,26);root.add(sp);
box(28,.15,20,0,.08,0,mat.turf,sp,false);const tr=new T.Mesh(new T.RingGeometry(7,9.2,40),mat.track);tr.rotation.x=-Math.PI/2;tr.scale.set(1.35,1,.95);tr.position.y=.2;sp.add(tr);
[-13.5,13.5].forEach(x=>{box(.2,2.4,3,x,1.2,0,mat.white,sp);});
// cricket
const cr=new T.Group();cr.position.set(26,0,28);root.add(cr);
box(24,.15,20,0,.08,0,mat.turf,cr,false);box(3,.2,14,0,.2,0,mat.pitch,cr,false);
for(let i=-1;i<=1;i+=2)box(3.4,3,.1,i*5.5,1.5,0,new T.MeshBasicMaterial({color:0xffffff,wireframe:true,transparent:true,opacity:.5}),cr,false).rotation.y=Math.PI/2;
// fountain
const fo=new T.Group();fo.position.set(0,0,16);root.add(fo);
const fb=new T.Mesh(new T.CylinderGeometry(4,4.4,.9,24),mat.paved);fb.position.y=.45;fb.castShadow=fb.receiveShadow=true;fo.add(fb);
const water=new T.Mesh(new T.CylinderGeometry(3.6,3.6,.1,24),new T.MeshStandardMaterial({color:0x4aa3d8,roughness:.05,metalness:.3,transparent:true,opacity:.85}));water.position.y=.9;fo.add(water);
const jets=new T.InstancedMesh(new T.SphereGeometry(.14,6,6),new T.MeshBasicMaterial({color:0xcfeaff}),mob?24:48);fo.add(jets);
// trees
const tpos=[];for(let i=0;i<(mob?26:44);i++){const a=i/(mob?26:44)*Math.PI*2,r=44+(i%3)*2;tpos.push([Math.cos(a)*r*1.0,Math.sin(a)*r*.98]);}
[[-12,14],[12,14],[-12,30],[12,30],[-38,-30],[38,-30],[-8,-30],[8,-30]].forEach(p=>tpos.push(p));
const tc=tpos.length,trunks=new T.InstancedMesh(new T.CylinderGeometry(.25,.4,3,5),mat.trunk,tc),crowns=new T.InstancedMesh(new T.IcosahedronGeometry(2.2,0),mat.leaf,tc);
crowns.castShadow=true;root.add(trunks,crowns);const d=new T.Object3D();
tpos.forEach((p,i)=>{d.position.set(p[0],1.5,p[1]);d.rotation.set(0,0,0);d.scale.setScalar(1);d.updateMatrix();trunks.setMatrixAt(i,d.matrix)});
// lamps
const lp=[];for(let z=-30;z<=40;z+=14){lp.push([-4.5,z],[4.5,z])}lp.push([-40,50],[40,50]);
const poles=new T.InstancedMesh(new T.CylinderGeometry(.08,.1,5,5),mat.dark,lp.length),heads=new T.InstancedMesh(new T.SphereGeometry(.35,8,8),mat.lamp,lp.length);root.add(poles,heads);
lp.forEach((p,i)=>{d.position.set(p[0],2.5,p[1]);d.updateMatrix();poles.setMatrixAt(i,d.matrix);d.position.y=5.1;d.updateMatrix();heads.setMatrixAt(i,d.matrix)});
// cars
const cols=[0xb0b4ba,0x1f3a5f,0x7a1f26,0xe9e9e9,0x2b2b2b,0x5c6670];
function car(x,z,c,ry){const g=new T.Group(),m=M(c,.35,.6);box(1.9,.7,4.2,0,.55,0,m,g);box(1.6,.6,2.2,0,1.15,-.2,mat.glass,g,false);g.position.set(x,0,z);g.rotation.y=ry||0;root.add(g);return g}
for(let i=0;i<6;i++){car(35+(i%2)*7,0+Math.floor(i/2)*5-1,cols[i]);}
const mover=car(-60,58,0xd8d8d8,Math.PI/2);
// clouds
const clouds=[];for(let i=0;i<5;i++){const g=new T.Group(),cm=new T.MeshBasicMaterial({color:0xffffff,transparent:true,opacity:.55,fog:false});for(let j=0;j<4;j++){const s=new T.Mesh(new T.SphereGeometry(7+j,8,6),cm);s.position.set(j*8,Math.sin(j)*2,0);s.scale.y=.45;g.add(s)}g.position.set(-150+i*70,95+i*4,-60+(i%3)*50);root.add(g);clouds.push(g)}
// particles
const pn=mob?60:160,pa=new Float32Array(pn*3);for(let i=0;i<pn;i++){pa[i*3]=(Math.random()-.5)*110;pa[i*3+1]=Math.random()*18+1;pa[i*3+2]=(Math.random()-.5)*100}
const pg=new T.BufferGeometry();pg.setAttribute("position",new T.BufferAttribute(pa,3));const parts=new T.Points(pg,new T.PointsMaterial({color:0xffe6b0,size:.35,transparent:true,opacity:.5,depthWrite:false}));root.add(parts);
// zones: pick volumes + highlight plates
const picks=[],zones={};
RPS.ZONES.forEach(z=>{const s=z.size,pk=new T.Mesh(new T.BoxGeometry(s[0],s[1],s[2]),new T.MeshBasicMaterial({visible:false}));pk.position.set(z.pos[0],s[1]/2,z.pos[1]);pk.userData.zone=z.id;root.add(pk);picks.push(pk);
const pl=new T.Mesh(new T.RingGeometry(1,1.06,4,1,Math.PI/4),new T.MeshBasicMaterial({color:0xc8a96a,transparent:true,opacity:0,side:T.DoubleSide,depthWrite:false}));
pl.rotation.x=-Math.PI/2;pl.position.set(z.pos[0],.35,z.pos[1]);pl.scale.set(s[0]*.72,s[2]*.72,1);root.add(pl);
zones[z.id]={plate:pl,level:0,target:0}});
const jd=new T.Object3D();
function update(t){
if(stage.quality==="high"){for(let i=0;i<tc;i++){d.position.set(tpos[i][0],4.2,tpos[i][1]);d.rotation.set(0,i,Math.sin(t*.8+i)*.04);d.scale.setScalar(1);d.updateMatrix();crowns.setMatrixAt(i,d.matrix)}crowns.instanceMatrix.needsUpdate=true}
else if(!update.once){for(let i=0;i<tc;i++){d.position.set(tpos[i][0],4.2,tpos[i][1]);d.rotation.set(0,0,0);d.updateMatrix();crowns.setMatrixAt(i,d.matrix)}crowns.instanceMatrix.needsUpdate=true;update.once=1}
for(let i=0;i<jets.count;i++){const ph=(t*.9+i/jets.count)%1,a=i*2.4,r=ph*2.6;jd.position.set(Math.cos(a)*r,.9+Math.sin(ph*Math.PI)*2.2*(.6+(i%4)*.15),Math.sin(a)*r);jd.updateMatrix();jets.setMatrixAt(i,jd.matrix)}jets.instanceMatrix.needsUpdate=true;
water.rotation.y=t*.1;mover.position.x=((t*6+60)%120)-60;
clouds.forEach((c,i)=>{c.position.x+=.01*(1+i*.2);if(c.position.x>170)c.position.x=-170});
parts.rotation.y=t*.01;parts.position.y=Math.sin(t*.4)*.6;
for(const k in zones){const z=zones[k];z.level+=(z.target-z.level)*.15;z.plate.material.opacity=z.level*(.65+.25*Math.sin(t*3))}}
function setNight(n){mat.glass.emissiveIntensity=n*.9;mat.lamp.emissiveIntensity=.1+n*3}
stage.campus={setNight};stage.onFrame(update);
return{picks,setHover(id,on){if(zones[id])zones[id].target=on?.5:(zones[id].selected?1:0)},select(id){for(const k in zones){zones[k].selected=k===id;zones[k].target=k===id?1:0}},setNight}};
})();
